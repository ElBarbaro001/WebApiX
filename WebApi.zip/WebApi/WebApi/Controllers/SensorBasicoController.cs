﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Text.RegularExpressions;
using WebApi.Models.Configuracion.Parametrizacion.Basico;
using WebApi.Services;
/*Mediante este controlador exponemos mediante EndPoints cada una de las consultas SQL que se hacen en la Clase SensorBasicoService.
 * Se debe de utilizar un metodo GET, POST, PUT o DELETE dependiendo del tipo de consulta SQL, cuando una consulta es trae datos se utiliza el metodo GET
 * o PUT ambos reciben parametros que pueden darle un perfil a la consulta SQL.
 */
namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SensorBasicoController : Controller
    {
        private readonly ISensorBasico _sensorBasico;
        public SensorBasicoController(ISensorBasico sensorBasico)
        {
            _sensorBasico = sensorBasico;
        }
        [HttpGet]
        [Route("/Variables")]
        public async Task<IActionResult> Variables()
        {
            var result = await _sensorBasico.Variables();
            return Ok(result);
        }
        [HttpGet]
        [Route("/Sensores")]
        public async Task<IActionResult> Sensores()
        {
            var result = await _sensorBasico.Sensores();
            return Ok(result);
        }
        [HttpGet]
        [Route("/PromedioVariablesSensorBasico")]
        public async Task<IActionResult> PromedioVariables(string region, string municipio, string vereda,string sensor)
        {
            var result = await _sensorBasico.PromedioVariables(region,municipio,vereda,sensor);
            return Ok(result);
        }
        [HttpGet]
        [Route("/Municipios")]
        public async Task<IActionResult> Municipios()
        {
            var result = await _sensorBasico.Municipios();
            return Ok(result);
        }
        [HttpGet]
        [Route("/Veredas")]
        public async Task<IActionResult> Veredas()
        {
            var result = await _sensorBasico.Veredas();
            return Ok(result);
        }
        //Endpoints Sensor Basico
        [HttpGet]
        [Route("/Temperatura")]
        public async Task<IActionResult> Temperatura(string region,string municipio,string vereda,string sensor)
        {
            var result = await _sensorBasico.Temperatura(region,municipio,vereda,sensor);
            return Ok(result);
        }
        [HttpGet]
        [Route("/Humedad")]
        public async Task<IActionResult> Humedad(string region, string municipio, string vereda,string sensor)
        {
            var result = await _sensorBasico.Humedad(region,municipio,vereda,sensor);
            return Ok(result);
        }
        [HttpGet]
        [Route("/PresionAtmosferica")]
        public async Task<IActionResult> PresionAtmosferica(string region, string municipio, string vereda,string sensor)
        {
            var result = await _sensorBasico.PresionAtmosferica(region, municipio, vereda,sensor);
            return Ok(result);
        }
        [HttpGet]
        [Route("/Altitud")]
        public async Task<IActionResult> Altitud(string region, string municipio, string vereda,string sensor)
        {
            var result = await _sensorBasico.Altitud(region, municipio, vereda,sensor);
            return Ok(result);
        }
        [HttpGet]
        [Route("/IndiceUV")]
        public async Task<IActionResult> IndiceUV(string region, string municipio, string vereda,string sensor)
        {
            var result = await _sensorBasico.IndiceUV(region, municipio, vereda,sensor);
            return Ok(result);
        }
        [HttpGet]
        [Route("/LongitudOndaVisible")]
        public async Task<IActionResult> LongitudOndaVisible(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.LongitudOndaVisible(region, municipio, vereda, sensor);
            return Ok(result);
        }
        [HttpGet]
        [Route("/LongitudOndaInfrarrojo")]
        public async Task<IActionResult> LongitudOndaInfrarrojo(string region, string municipio, string vereda,string sensor)
        {
            var result = await _sensorBasico.LongitudOndaInfrarrojo(region, municipio, vereda,sensor);
            return Ok(result);
        }
        [HttpGet]
        [Route("/Precipitacion")]
        public async Task<IActionResult> Precipitacion(string region, string municipio, string vereda,string sensor)
        {
            var result = await _sensorBasico.Precipitacion(region, municipio, vereda,sensor);
            return Ok(result);
        }
        [HttpGet]
        [Route("/VelocidadViento")]
        public async Task<IActionResult> VelocidadViento(string region, string municipio, string vereda,string sensor)
        {
            var result = await _sensorBasico.VelocidadViento(region, municipio, vereda,sensor);
            return Ok(result);
        }
        [HttpGet]
        [Route("/DireccionViento")]
        public async Task<IActionResult> DireccionViento(string region, string municipio, string vereda,string sensor)
        {
            var result = await _sensorBasico.DireccionViento(region, municipio, vereda,sensor);
            return Ok(result);
        }
        [HttpGet]
        [Route("/NivelCarga")]
        public async Task<IActionResult> NivelCarga(string region, string municipio, string vereda,string sensor)
        {
            var result = await _sensorBasico.NivelCarga(region, municipio, vereda,sensor);
            return Ok(result);
        }
        [HttpGet]
        [Route("/IntensidadLuz")]
        public async Task<IActionResult> IntensidadLuz(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.IntensidadLuz(region, municipio, vereda,sensor);
            return Ok(result);
        }
        //Sensor Fermentacion
        //Varialbes Sensor Fermentacion
        [HttpGet]
        [Route("/VariablesFermentacion")]
        public async Task<IActionResult> VariablesFermentacion()
        {
            var result = await _sensorBasico.VariablesFermentacion();
            return Ok(result);
        }
        //Promedio Variables Sensor Fermentacion
        [HttpGet]
        [Route("/PromedioVariablesFermentacion")]
        public async Task<IActionResult> PromedioVaraiblesFermentacion(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.PromedioVariablesFermentacion(region,municipio,vereda,sensor);
            return Ok(result);
        }
        //Temperatura Ambiente
        [HttpGet]
        [Route("/TemperaturaAmbiente")]
        public async Task<IActionResult> TemperaturaAmbiente(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.TemperaturaAmbiente(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Temperatura Ambiente
        [HttpGet]
        [Route("/TemperaturaMasa")]
        public async Task<IActionResult> TemperaturaMasa(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.TemperaturaMasa(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Temperatura Ambiente
        [HttpGet]
        [Route("/HumedadAmbiente")]
        public async Task<IActionResult> HumedadAmbiente(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.HumedadAmbiente(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Temperatura Ambiente
        [HttpGet]
        [Route("/HumedadMasa")]
        public async Task<IActionResult> HumedadMasa(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.HumedadMasa(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Ph
        [HttpGet]
        [Route("/Ph")]
        public async Task<IActionResult> Ph(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.Ph(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Temperatura Ambiente
        [HttpGet]
        [Route("/NivelCargaFermentacion")]
        public async Task<IActionResult> NivelCargaFermentacion(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.NivelCargaFermentacion(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Sensor Horno
        //Promedio Variables Sensor Fermentacion
        [HttpGet]
        [Route("/VariablesHorno")]
        public async Task<IActionResult> VariablesHorno()
        {
            var result = await _sensorBasico.VariablesHorno();
            return Ok(result);
        }
        //Promedio Variables Sensor Fermentacion
        [HttpGet]
        [Route("/PromedioVariablesHorno")]
        public async Task<IActionResult> PromedioVariablesHorno(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.PromedioVariablesHorno(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Temperatura Horno
        [HttpGet]
        [Route("/TemperaturaHorno")]
        public async Task<IActionResult> TemperaturaHorno(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.TemperaturaHorno(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Humedad Horno
        [HttpGet]
        [Route("/HumedadHorno")]
        public async Task<IActionResult> HumedadHorno(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.HumedadHorno(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Nivel Carga Horno
        [HttpGet]
        [Route("/NivelCargaHorno")]
        public async Task<IActionResult> NivelCargaHorno(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.NivelCargaHorno(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Sensor Suelo Superficial
        //Variables
        [HttpGet]
        [Route("/VariablesSueloSuperficial")]
        public async Task<IActionResult> VariablesSueloSuperficial()
        {
            var result = await _sensorBasico.VariablesSueloSuperficial();
            return Ok(result);
        }
        //Promedio Variables Sensor Fermentacion
        [HttpGet]
        [Route("/PromedioVariablesSuelo")]
        public async Task<IActionResult> PromedioVariablesSuelo(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.PromedioVariablesSuelo(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Temperatura Suelo
        [HttpGet]
        [Route("/TemperaturaSuelo")]
        public async Task<IActionResult> TemperaturaSuelo(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.TemperaturaSuelo(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Humedad Suelo
        [HttpGet]
        [Route("/HumedadSuelo")]
        public async Task<IActionResult> HumedadSuelo(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.HumedadSuelo(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Temperatura Ambiente Suelo
        [HttpGet]
        [Route("/TemperaturaAmbienteSuelo")]
        public async Task<IActionResult> TemperaturaAmbienteSuelo(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.TemperaturaAmbienteSuelo(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Humedad Relativa Ambiente
        [HttpGet]
        [Route("/HumedadRelativaAmbiente")]
        public async Task<IActionResult> HumedadRelativaAmbiente(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.HumedadRelativaAmbiente(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Luz Ambiente
        [HttpGet]
        [Route("/LuzAmbiente")]
        public async Task<IActionResult> LuzAmbiente(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.LuzAmbiente(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Conductividad Electrica
        [HttpGet]
        [Route("/ConductividadElectrica")]
        public async Task<IActionResult> ConductividadElectrica(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.ConductividadElectrica(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Nivel Carga Suelo
        [HttpGet]
        [Route("/NivelCargaSuelo")]
        public async Task<IActionResult> NivelCargaSuelo(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.NivelCargaSuelo(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Sensor Suelo Superficial Avanzado
        //Variables
        [HttpGet]
        [Route("/VariablesSueloSuperficialAvanzado")]
        public async Task<IActionResult> VariablesSueloSuperficialAvanzado()
        {
            var result = await _sensorBasico.VariablesSueloSuperficialAvanzado();
            return Ok(result);
        }
        //Promedio Variables
        [HttpGet]
        [Route("/PromedioVariablesSueloAvanzado")]
        public async Task<IActionResult> PromedioVariablesSueloAvanzado(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.PromedioVariablesSueloAvanzado(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Temperatura
        [HttpGet]
        [Route("/TemperaturaSueloA")]
        public async Task<IActionResult> TemperaturaSueloA(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.TemperaturaSueloA(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Promedio Variables
        [HttpGet]
        [Route("/HumedadSueloA")]
        public async Task<IActionResult> HumedadSueloA(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.HumedadSueloA(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Promedio Variables
        [HttpGet]
        [Route("/ConductividadElectricaSueloA")]
        public async Task<IActionResult> ConductividadElectricaSueloA(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.ConductividadElectricaSueloA(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //PH
        [HttpGet]
        [Route("/PhSueloA")]
        public async Task<IActionResult> PhSueloA(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.PhSueloA(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //NPK
        [HttpGet]
        [Route("/NpkSueloA")]
        public async Task<IActionResult> NpkSueloA(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.NpkSueloA(region, municipio, vereda, sensor);
            return Ok(result);
        }
        //Nivel Carga
        [HttpGet]
        [Route("/NivelCargaSueloA")]
        public async Task<IActionResult> NivelCargaSueloA(string region, string municipio, string vereda, string sensor)
        {
            var result = await _sensorBasico.NivelCargaSueloA(region, municipio, vereda, sensor);
            return Ok(result);
        }

        /* Login
         */
        //Login
        [HttpGet]
        [Route("/Login")]
        public async Task<IActionResult> Login()
        {
            var result = await _sensorBasico.Login();
            return Ok(result);
        }
        //----------------------------> Sensor Basico

        //---> Sensores
        [HttpGet]
        [Route("/SensorParametrizacion")]
        public async Task<IActionResult> SensoresParametrizacion()
        {
            var result = await _sensorBasico.SensoresParametrizacion();
            return Ok(result);
        }
        //---> Variables
        [HttpGet]
        [Route("/VariablesSensores")]
        public async Task<IActionResult> VariablesSensores(string sensor)
        {
            var result = await _sensorBasico.VariablesSensores(sensor);
            return Ok(result);
        }
        //---> Multivariable
        
        [HttpPut]
        [Route("/ActualizarVarSensores")]
        public async Task<IActionResult> ActualizarVarSensores([FromBody] variablesSensorBasico variablebasico,string sensor,string variable)
        {
            var result = await _sensorBasico.ActualizarVarSensores(variablebasico,sensor,variable);
            return Ok(result);
        }
        [HttpGet]
        [Route("/DatosBasico")]
        public async Task<IActionResult> DatosBasico(string sensor, string variable)
        {
            var result = await _sensorBasico.DatosBasico(sensor,variable);
            return Ok(result);
        }
        [HttpGet]
        [Route("/DatosBasicoProm")]
        public async Task<IActionResult> DatosBasicoProm(string sensor, string variable)
        {
            var result = await _sensorBasico.DatosBasicoProm(sensor, variable);
            return Ok(result);
        }
    }
}