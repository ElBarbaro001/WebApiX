﻿namespace WebApi.Models.Configuracion.Login
{
    public class Login
    {
        public string? usuario { get; set; }
        public string? password { get; set; }
    }
}
