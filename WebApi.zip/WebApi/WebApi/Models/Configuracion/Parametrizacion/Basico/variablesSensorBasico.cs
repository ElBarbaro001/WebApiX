﻿namespace WebApi.Models.Configuracion.Parametrizacion.Basico
{
    public class variablesSensorBasico
    {
        public int? co_value1 { get; set; }
        public int? co_value2 { get; set; }
        public string? co_mensaje { get; set; }
        public int? cc_value1 { get; set; }
        public int? cc_value2 { get; set; }
        public string? cc_mensaje { get; set; }
        public string? cm_mensaje { get; set; }
        public int? rango { get; set; }
    }
}
