﻿namespace WebApi.Models.Configuracion.Parametrizacion
{
    public class SensoresParametrizacion
    {
        public string? variable { get; set; }
    }
}
