﻿namespace WebApi.Models.Configuracion.Parametrizacion
{
    public class listaSensore
    {
    }
}
