﻿namespace WebApi.Models.Municipios
{
    public class Municipios
    {
        public string? municipio { get; set; }
    }
}
