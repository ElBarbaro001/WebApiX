﻿namespace WebApi.Models.Nombre_Variables
{
    public class Variables
    {
        public string? variable { get; set; }
    }
}
