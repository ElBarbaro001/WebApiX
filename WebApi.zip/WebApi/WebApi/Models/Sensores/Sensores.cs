﻿namespace WebApi.Models.Sensores
{
    public class Sensores
    {
        public string? sensores { get; set; }
    }
}
