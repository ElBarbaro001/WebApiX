﻿namespace WebApi.Models
{
    public class VariablesBasico
    {
        public string? variable { get; set; }
    }
}
