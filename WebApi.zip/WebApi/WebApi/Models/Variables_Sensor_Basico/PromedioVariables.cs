﻿namespace WebApi.Models.Variables_Sensor_Basico
{
    public class PromedioVariables
    {
        public string? temperatura { get; set; }
        public string? humedad_relativa { get; set; }
        public string? presion_atmosferica { get; set; }
        public string? altitud { get; set; }
        public string? indice_uv { get; set; }
        public string? longitud_onda_visible { get; set; }
        public string? velocidad_viento { get; set; }
        public string? nivel_carga { get; set; }
        public string? direccion_viento { get; set; }
        public string? intensidad_luz { get; set; }
        public string? longitud_onda_infrarrojo { get; set; }
        public string? precipitacion_lluvia { get; set; }

    }
}
