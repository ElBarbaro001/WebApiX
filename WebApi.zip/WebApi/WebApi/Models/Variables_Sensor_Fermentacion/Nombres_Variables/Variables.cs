﻿namespace WebApi.Models.Variables_Sensor_Fermentacion.Nombres_Variables
{
    public class Variables
    {
        public string? variable { get; set; }

    }
}
