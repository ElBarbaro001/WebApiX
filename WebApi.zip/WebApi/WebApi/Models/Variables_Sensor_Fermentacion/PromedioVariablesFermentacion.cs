﻿namespace WebApi.Models.Variables_Sensor_Fermentacion
{
    public class PromedioVariablesFermentacion
    {
        public string? temperatura_ambiente { get; set; }
        public string? temperatura_masa { get; set; }
        public string? humedad_ambiente { get; set; }
        public string? humedad_masa { get; set; }
        public string? ph { get; set; }
        public string? nivel_carga { get; set; }
    }
}
