﻿namespace WebApi.Models.Variables_Sensor_Horno
{
    public class PromedioVariablesHorno
    {

        public string? temperatura { get; set; }
        public string? humedad { get; set; }
        public string? nivel_carga { get; set; }
    }
}
