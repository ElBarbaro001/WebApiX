﻿namespace WebApi.Models.Variables_Sensor_Suelo_Superficial
{
    public class NivelCargaSuelo
    {
        public int? uno { get; set; }
        public int? dos { get; set; }
        public int? tres { get; set; }
        public int? cuatro { get; set; }
        public int? cinco { get; set; }
        public int? seis { get; set; }
        public int? siete { get; set; }
        public DateTime? funo { get; set; }
        public DateTime? fdos { get; set; }
        public DateTime? ftres { get; set; }
        public DateTime? fcuatro { get; set; }
        public DateTime? fcinco { get; set; }
        public DateTime? fseis { get; set; }
        public DateTime? fsiete { get; set; }
    }
}
