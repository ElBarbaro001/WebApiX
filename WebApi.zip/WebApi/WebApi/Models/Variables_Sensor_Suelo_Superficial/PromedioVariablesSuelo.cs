﻿namespace WebApi.Models.Variables_Sensor_Suelo_Superficial
{
    public class PromedioVariablesSuelo
    {
        public string? temperatura_suelo { get; set; }
        public string? humedad_suelo { get; set; }
        public string? temperatura_ambiente { get; set; }
        public string? humedad_relativa_ambiente { get; set; }
        public string? luz_ambiente { get; set; }
        public string? conductividad_electrica { get; set; }
        public string? nivel_carga { get; set; }
    }
}
