﻿namespace WebApi.Models.Variables_Sensor_Suelo_Superficial_Avanzado
{
    public class PromedioVariablesSueloAvanzado
    {
        public string? temperatura { get; set; }
        public string? humedad { get; set; }
        public string? conductividad_electrica { get; set; }
        public string? ph { get; set; }
        public string? npk { get; set; }
        public string? nivel_carga { get; set; }
    }
}
