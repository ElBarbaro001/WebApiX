﻿namespace WebApi.Models.Veredas
{
    public class Veredas
    {
        public string? vereda { get; set; }
    }
}
