﻿using Dapper;
using Npgsql;
using System.Data;
/*Con esta funcion nos conectamos por medio del Controlador de Postgresql al servidor del mismo
 * Se crea una cadena de conexion mediante el GetConnectionString a la Base de Datos que tengamos como objetivo.
 * En nuestro caso la base de datos es IOT
 */
namespace WebApi.Services
{
    public class DbService : IDbService
    {
        private readonly IDbConnection _db;
        public DbService(IConfiguration configuration)
        {
            _db = new NpgsqlConnection(configuration.GetConnectionString("IOT"));
        }
        public async Task<T> GetAsync<T>(string command, object parms)
        {
            T? result;
            result = (await _db.QueryAsync<T>(command, parms).ConfigureAwait(false)).FirstOrDefault()!;
            return result;
        }
        public async Task<List<T>> TraerDatosDB<T>(string command, object parms)
        {
            List<T> result = new List<T>();
            result = (await _db.QueryAsync<T>(command, parms)).ToList();
            return result;
        }
        public async Task<int> EditData(string command, object parms)
        {
            int result;
            result = await _db.ExecuteAsync(command, parms);
            return result;
        }
    }
}
