﻿namespace WebApi.Services
{
    /* Mediante esta Interfaz accedemos a los metodo GetAsyc, TraerDatosDB y EditData que estan configurados en el DBService
     */
    public interface IDbService
    {
        Task<T> GetAsync<T>(string command, object parms);
        Task<List<T>> TraerDatosDB<T>(string command, object parms);
        Task<int> EditData(string command, object parms);    
    }
}