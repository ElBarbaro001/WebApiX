﻿using WebApi.Models;
using WebApi.Models.Municipios;
using WebApi.Models.Nombre_Variables;
using WebApi.Models.Sensores;
using WebApi.Models.Variables_Sensor_Basico;
using WebApi.Models.Variables_Sensor_Fermentacion;
using WebApi.Models.Variables_Sensor_Horno;
using WebApi.Models.Variables_Sensor_Suelo_Superficial;
using WebApi.Models.Variables_Sensor_Suelo_Superficial_Avanzado;
using WebApi.Models.Configuracion.Login;
using WebApi.Models.Configuracion.Parametrizacion.Basico;
using WebApi.Models.Veredas;
using WebApi.Models.Configuracion.Parametrizacion;
using System.Globalization;
/*En esta Clase creamos cada una de las tareas que se ejecutan en la Clase SensorBasicoService, creamos un Task Lista en donde cargamos los datos
 * Provenientes de las consultas SQL.
 */

namespace WebApi.Services
{
    public interface ISensorBasico
    {
        Task<List<Models.Nombre_Variables.Variables>> Variables();
        Task<List<Municipios>> Municipios();
        Task<List<Veredas>> Veredas();
        Task<List<Sensores>> Sensores();
        //Variables Sensor Basico
        Task<List<PromedioVariables>> PromedioVariables(string region, string municipio, string vereda, string sensor);
        Task<List<Temperatura>> Temperatura(string region, string municipio, string vereda, string sensor);
        Task<List<Humedad>> Humedad(string region, string municipio, string vereda,string sensor);
        Task<List<PresionAtmosferica>> PresionAtmosferica(string region, string municipio, string vereda,string sensor);
        Task<List<Altitud>> Altitud(string region, string municipio, string vereda,string sensor);
        Task<List<IndiceUV>> IndiceUV(string region, string municipio, string vereda,string sensor);
        Task<List<LongitudOndaVisible>> LongitudOndaVisible(string region, string municipio, string vereda,string sensor);
        Task<List<LongitudOndaInfrarrojo>> LongitudOndaInfrarrojo(string region, string municipio, string vereda,string sensor);
        Task<List<Precipitacion>> Precipitacion(string region, string municipio, string vereda,string sensor);
        Task<List<VelocidadViento>> VelocidadViento(string region, string municipio, string vereda,string sensor);
        Task<List<DireccionViento>> DireccionViento(string region, string municipio, string vereda,string sensor);
        Task<List<NivelCarga>> NivelCarga(string region, string municipio, string vereda,string sensor);
        Task<List<IntensidadLuz>> IntensidadLuz(string region, string municipio, string vereda,string sensor);
        // Variables Sensor Fermentacion
        Task<List<Models.Nombre_Variables.Variables>> VariablesFermentacion();
        Task<List<PromedioVariablesFermentacion>> PromedioVariablesFermentacion(string region, string municipio, string vereda, string sensor);
        Task<List<TemperaturaAmbiente>> TemperaturaAmbiente(string region, string municipio, string vereda, string sensor);
        Task<List<TemperaturaMasa>> TemperaturaMasa(string region, string municipio, string vereda, string sensor);
        Task<List<HumedadAmbiente>> HumedadAmbiente(string region, string municipio, string vereda, string sensor);
        Task<List<HumedadMasa>> HumedadMasa (string region, string municipio, string vereda, string sensor);
        Task<List<Ph>> Ph(string region, string municipio, string vereda, string sensor);
        Task<List<NivelCargaFermentacion>> NivelCargaFermentacion(string region, string municipio, string vereda, string sensor);
        // Variables Sensor Fermentacion
        Task<List<Models.Nombre_Variables.Variables>> VariablesHorno();
        Task<List<PromedioVariablesHorno>> PromedioVariablesHorno(string region, string municipio, string vereda, string sensor);
        Task<List<Models.Variables_Sensor_Horno.TemperaturaHorno>> TemperaturaHorno(string region, string municipio, string vereda, string sensor);
        Task<List<HumedadHorno>> HumedadHorno(string region, string municipio, string vereda, string sensor);
        Task<List<NivelCargaHorno>> NivelCargaHorno(string region, string municipio, string vereda, string sensor);
        // Variables Sensor Suelo Superficial
        Task<List<Models.Nombre_Variables.Variables>> VariablesSueloSuperficial();
        Task<List<PromedioVariablesSuelo>> PromedioVariablesSuelo(string region, string municipio, string vereda, string sensor);
        Task<List<TemperaturaSuelo>> TemperaturaSuelo(string region, string municipio, string vereda, string sensor);
        Task<List<HumedadSuelo>> HumedadSuelo(string region, string municipio, string vereda, string sensor);
        Task<List<TemperaturaAmbienteSuelo>> TemperaturaAmbienteSuelo(string region, string municipio, string vereda, string sensor);
        Task<List<HumedadRelativaAmbiente>> HumedadRelativaAmbiente(string region, string municipio, string vereda, string sensor);
        Task<List<LuzAmbiente>> LuzAmbiente(string region, string municipio, string vereda, string sensor);
        Task<List<ConductividadElectrica>> ConductividadElectrica(string region, string municipio, string vereda, string sensor);
        Task<List<NivelCargaSuelo>> NivelCargaSuelo(string region, string municipio, string vereda, string sensor);
        // Variables Sensor Suelo Superficial Avanzado
        Task<List<Models.Nombre_Variables.Variables>> VariablesSueloSuperficialAvanzado();
        Task<List<PromedioVariablesSueloAvanzado>> PromedioVariablesSueloAvanzado(string region, string municipio, string vereda, string sensor);
        Task<List<TemperaturaSueloA>> TemperaturaSueloA(string region, string municipio, string vereda, string sensor);
        Task<List<HumedadSueloA>> HumedadSueloA(string region, string municipio, string vereda, string sensor);
        Task<List<ConductividadElectricaSueloA>> ConductividadElectricaSueloA(string region, string municipio, string vereda, string sensor);
        Task<List<PhSueloA>> PhSueloA(string region, string municipio, string vereda, string sensor);
        Task<List<NpkSueloA>> NpkSueloA(string region, string municipio, string vereda, string sensor);
        Task<List<NivelCargaSueloA>> NivelCargaSueloA(string region, string municipio, string vereda, string sensor);
        //Login
        Task<List<Login>> Login();
        // ----------------------------------------- Parametrizacion Sensores ------------------------------------------- !!!
        Task<List<SensoresParametrizacion>> SensoresParametrizacion();
        Task<List<VariablesBasico>> VariablesSensores(string sensor);
        //-----------------------> Sensor Basico
        Task<variablesSensorBasico> ActualizarVarSensores(variablesSensorBasico variablesBasico,string sensor,string variable);
        Task<List<variablesSensorBasico>> DatosBasico(string sensor,string variable);
        Task<List<variablesSensorBasico>> DatosBasicoProm(string sensor,string variable);
    }
}