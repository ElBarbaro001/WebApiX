﻿using WebApi.Models;
using WebApi.Models.Municipios;
using WebApi.Models.Nombre_Variables;
using WebApi.Models.Sensores;
using WebApi.Models.Variables_Sensor_Basico;
using WebApi.Models.Variables_Sensor_Fermentacion;
using WebApi.Models.Variables_Sensor_Horno;
using WebApi.Models.Variables_Sensor_Suelo_Superficial;
using WebApi.Models.Variables_Sensor_Suelo_Superficial_Avanzado;
using WebApi.Models.Configuracion.Login;
using WebApi.Models.Veredas;
using System.Data.Common;
using WebApi.Models.Configuracion.Parametrizacion.Basico;
using WebApi.Models.Configuracion.Parametrizacion;
/*En esta clase creamos cada una de las funciones:
 * - Consultar
 * - Ingresar
 * De la base de datos, para que una funcion reciba los datos solicitados, se debe crear un modelo en el cual cada atributo debe llamarse igual
 * a la columna que arroja la consulta sql esto para evitar que se carguen valores nulos en las columnas.
 * /*/
namespace WebApi.Services
{
    public class SensorBasicoService : ISensorBasico
    {
        private readonly IDbService _dbService;
        //Acceder a la Interfaz del Servicio a Base de Datos
        public SensorBasicoService(IDbService dbService)
        {
            _dbService = dbService;
        }
        //Consulta todas las Variables
        public async Task<List<Variables>> Variables()
        {
            var variables = await _dbService.TraerDatosDB<Variables>("select distinct   " +
                "column_name variable  " +
                "from     " +
                "information_schema.columns  " +
                "where   " +
                "table_name = 'sensor_basico'  " +
                "and   ordinal_position between 3 and 14", new { });
            return variables;
        }
        //Sensores
        public async Task<List<Sensores>> Sensores()
        {
            var sensores = await _dbService.TraerDatosDB<Sensores>("select distinct table_name sensores from information_schema.columns where table_schema = 'uraba' and ordinal_position = 1 and table_name like 's%'", new { });
            return sensores;
        }
        //Promedios Variables
        public async Task<List<PromedioVariables>> PromedioVariables(string region, string municipio, string vereda, string sensor)
        {
            var promvariables = await _dbService.TraerDatosDB<PromedioVariables>("select " +
                "cast(sum(s.temperatura)/count(s.temperatura)as int)temperatura," +
                "cast(sum(s.humedad_relativa)/count(s.humedad_relativa)as int)humedad_relativa," +
                "cast(sum(s.presion_atmosferica)/count(s.presion_atmosferica)as int)presion_atmosferica," +
                "cast(sum(s.altitud)/count(s.altitud)as int)altitud," +
                "cast(sum(s.indice_uv )/count(s.indice_uv)as int) indice_uv," +
                "cast(sum(s.longitud_onda_visible)/count(s.longitud_onda_visible)as int)longitud_onda_visible," +
                "cast(sum(s.velocidad_viento)/count(s.velocidad_viento)as int)velocidad_viento," +
                "cast(sum(s.nivel_carga)/count(s.nivel_carga)as int)nivel_carga," +
                "cast(sum(s.direccion_viento)/count(s.direccion_viento)as int)direccion_viento," +
                "cast(sum(s.intensidad_luz )/count(s.intensidad_luz)as int) intensidad_luz," +
                "cast(sum(s.longitud_onda_infrarrojo)/count(s.longitud_onda_infrarrojo)as int)longitud_onda_infrarrojo," +
                "cast(sum(s.precipitacion_lluvia )/count(s.precipitacion_lluvia)as int) precipitacion_lluvia " +
                "from " + region + "." + sensor + " s " +
                "inner join " + region + ".estacion e on e.id = s.id_estacion " +
                "where s.fecha_registro between    (current_date - interval '7 day') and now() " +
                "and e.municipio in ('" + municipio + "') and e.vereda in ('" + vereda + "')", new { });
            return promvariables;
        }
        //Municipios
        public async Task<List<Municipios>> Municipios()
        {
            var municipios = await _dbService.TraerDatosDB<Municipios>("select distinct   " +
                "e.municipio   " +
                "from     bajo_cauca.estacion e  " +
                "union all  " +
                "select distinct   " +
                "e.municipio   " +
                "from     magdalena_medio.estacion e  " +
                "union all  " +
                "select distinct   " +
                "e.municipio   " +
                "from     nordeste.estacion e  " +
                "union all  " +
                "select distinct   e.municipio   " +
                "from     norte.estacion e  " +
                "union all  " +
                "select distinct   " +
                "e.municipio   " +
                "from     occidente.estacion e  " +
                "union all  " +
                "select distinct   " +
                "e.municipio   " +
                "from     oriente.estacion e  " +
                "union all  " +
                "select distinct   " +
                "e.municipio    " +
                "from     suroeste.estacion e  " +
                "union all  " +
                "select distinct   e.municipio   " +
                "from      uraba.estacion e  " +
                "union all  " +
                "select distinct   " +
                "e.municipio   " +
                "from     " +
                "valle_de_aburra.estacion e", new { });
            return municipios;

        }
        //Veredas
        public async Task<List<Veredas>> Veredas()
        {
            var veredas = await _dbService.TraerDatosDB<Veredas>("select distinct   " +
                "e.vereda   from     bajo_cauca.estacion e  " +
                "union all  " +
                "select distinct   " +
                "e.vereda   from     magdalena_medio.estacion e  " +
                "union all  " +
                "select distinct   " +
                "e.vereda   from     nordeste.estacion e  " +
                "union all  " +
                "select distinct   " +
                "e.vereda   from     norte.estacion e  " +
                "union all  " +
                "select distinct   " +
                "e.vereda   from     occidente.estacion e  " +
                "union all  " +
                "select distinct   " +
                "e.vereda   from     oriente.estacion e  " +
                "union all  " +
                "select distinct   " +
                "e.vereda   from     suroeste.estacion e  " +
                "union all  " +
                "select distinct   " +
                "e.vereda   from      uraba.estacion e  " +
                "union all  " +
                "select distinct   " +
                "e.vereda   from     valle_de_aburra.estacion e", new { });
            return veredas;
        }
        /*-------------------------------------Inicio Sensores---------------------------------------------------
         * ------------------------ SENSOR BASICO  -----------------------------------------------
         * Se crean las clases async para controlar los tiempos de peticiones a la base de datos. Con esto garantizamos que la tarea se acaba cuando la peticion
         * llega a su fin. Esto para cada variable de cada uno de los sensores. Se reciben como parametros:
         *  - Region
         *  - Municipio
         *  - Vereda
         *  - Sensor
         *  Esto debido a que la Base de DAtos IOT esta distribuida en ESQUEMAS. Y en las consultas SQL estos parametros nos sirven para filtrar lo que necesitamos.
         */
        //Variables Sensor Basico
        //Temperatura
        public async Task<List<Temperatura>> Temperatura(string region, string municipio, string vereda, string sensor)
        {
            var temperatura = await _dbService.TraerDatosDB<Temperatura>("select distinct   " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + " ;"  , new { });
            return temperatura;
        }
        //Humedad Relativa
        public async Task<List<Humedad>> Humedad(string region, string municipio, string vereda, string sensor)
        {
            var presion = await _dbService.TraerDatosDB<Humedad>("select distinct   " +
                "(select   cast(sum(a.presion_atmosferica)/count(a.presion_atmosferica)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day')siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'7 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.presion_atmosferica)/count(a.presion_atmosferica)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day')seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'6 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.presion_atmosferica)/count(a.presion_atmosferica)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day')cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'5 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.presion_atmosferica)/count(a.presion_atmosferica)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day')cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'4 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.presion_atmosferica)/count(a.presion_atmosferica)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day')tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'3 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.presion_atmosferica)/count(a.presion_atmosferica)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day')dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'2 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.presion_atmosferica)/count(a.presion_atmosferica)as int) " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro  between current_date - interval '7 day' and current_date  - interval '1 day')promedio  " +
                "from   " +
                "" + region + "." + sensor + " s, " + region + ".estacion e   " +
                "where   e.municipio in ('" + municipio + "')  " +
                "and  e.vereda in ('" + vereda + "')", new { });
            return presion;
        }
        //Presion Atmosferica
        public async Task<List<PresionAtmosferica>> PresionAtmosferica(string region, string municipio, string vereda, string sensor)
        {
            var presion = await _dbService.TraerDatosDB<PresionAtmosferica>("select distinct   " +
                "(select   cast(sum(a.presion_atmosferica)/count(a.presion_atmosferica)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day')siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'7 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.presion_atmosferica)/count(a.presion_atmosferica)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day')seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'6 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.presion_atmosferica)/count(a.presion_atmosferica)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day')cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'5 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.presion_atmosferica)/count(a.presion_atmosferica)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day')cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'4 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.presion_atmosferica)/count(a.presion_atmosferica)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day')tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'3 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.presion_atmosferica)/count(a.presion_atmosferica)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day')dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'2 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.presion_atmosferica)/count(a.presion_atmosferica)as int) " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro  between current_date - interval '7 day' and current_date  - interval '1 day')promedio  " +
                "from   " +
                "" + region + "." + sensor + " s, " + region + ".estacion e   " +
                "where   e.municipio in ('" + municipio + "')  " +
                "and  e.vereda in ('" + vereda + "')", new { });
            return presion;

        }
        //Altitud
        public async Task<List<Altitud>> Altitud(string region, string municipio, string vereda, string sensor)
        {
            var altitud = await _dbService.TraerDatosDB<Altitud>("select distinct   " +
                "(select   cast(sum(a.altitud)/count(a.altitud)as int)  " +
                " from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day')siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                " from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'7 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.altitud)/count(a.altitud)as int)  " +
                " from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day')seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                " from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'6 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.altitud)/count(a.altitud)as int)  " +
                " from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day')cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                " from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'5 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.altitud)/count(a.altitud)as int)  " +
                " from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day')cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                " from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'4 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.altitud)/count(a.altitud)as int)  " +
                " from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day')tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                " from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'3 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.altitud)/count(a.altitud)as int)  " +
                " from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day')dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                " from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'2 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.altitud)/count(a.altitud)as int) " +
                " from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro  between current_date - interval '7 day' and current_date  - interval '1 day')promedio  " +
                " from   " +
                "" + region + "." + sensor + " s, " + region + ".estacion e   " +
                "where   e.municipio in ('" + municipio + "')  " +
                "and  e.vereda in ('" + vereda + "')", new { });
            return altitud;

        }
        //Indice UV
        public async Task<List<IndiceUV>> IndiceUV(string region, string municipio, string vereda, string sensor)
        {
            var indiceuv = await _dbService.TraerDatosDB<IndiceUV>("select distinct   " +
                "(select   cast(sum(a.indice_uv)/count(a.indice_uv)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day')siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'7 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.indice_uv)/count(a.indice_uv)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day')seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'6 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.indice_uv)/count(a.indice_uv)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day')cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'5 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.indice_uv)/count(a.indice_uv)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day')cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'4 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.indice_uv)/count(a.indice_uv)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day')tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'3 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.indice_uv)/count(a.indice_uv)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day')dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'2 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.indice_uv)/count(a.indice_uv)as int) " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro  between current_date - interval '7 day' and current_date  - interval '1 day')promedio  " +
                "from   " +
                "" + region + "." + sensor + " s, " + region + ".estacion e   " +
                "where   e.municipio in ('" + municipio + "')  " +
                "and  e.vereda in ('" + vereda + "')", new { });
            return indiceuv;

        }
        //Longitud de Onda Visible
        public async Task<List<LongitudOndaVisible>> LongitudOndaVisible(string region, string municipio, string vereda, string sensor)
        {
            var longitudondavisible = await _dbService.TraerDatosDB<LongitudOndaVisible>("select distinct   " +
                "(select   cast(sum(a.longitud_onda_visible)/count(a.longitud_onda_visible)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day')siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'7 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.longitud_onda_visible)/count(a.longitud_onda_visible)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day')seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'6 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.longitud_onda_visible)/count(a.longitud_onda_visible)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day')cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'5 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.longitud_onda_visible)/count(a.longitud_onda_visible)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day')cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'4 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.longitud_onda_visible)/count(a.longitud_onda_visible)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day')tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'3 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.longitud_onda_visible)/count(a.longitud_onda_visible)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day')dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'2 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.longitud_onda_visible)/count(a.longitud_onda_visible)as int) " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro  between current_date - interval '7 day' and current_date  - interval '1 day')promedio  " +
                "from   " +
                "" + region + "." + sensor + " s, " + region + ".estacion e   " +
                "where   e.municipio in ('" + municipio + "')  " +
                "and  e.vereda in ('" + vereda + "')", new { });
            return longitudondavisible;

        }
        //Longitud de Onda Infrarrojo
        public async Task<List<LongitudOndaInfrarrojo>> LongitudOndaInfrarrojo(string region, string municipio, string vereda, string sensor)
        {
            var longitudondainfra = await _dbService.TraerDatosDB<LongitudOndaInfrarrojo>("select distinct   " +
                "(select   cast(sum(a.longitud_onda_infrarrojo)/count(a.longitud_onda_infrarrojo)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day')siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'7 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.longitud_onda_infrarrojo)/count(a.longitud_onda_infrarrojo)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day')seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'6 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.longitud_onda_infrarrojo)/count(a.longitud_onda_infrarrojo)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day')cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'5 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.longitud_onda_infrarrojo)/count(a.longitud_onda_infrarrojo)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day')cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'4 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.longitud_onda_infrarrojo)/count(a.longitud_onda_infrarrojo)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day')tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'3 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.longitud_onda_infrarrojo)/count(a.longitud_onda_infrarrojo)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day')dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'2 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.longitud_onda_infrarrojo)/count(a.longitud_onda_infrarrojo)as int) " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro  between current_date - interval '7 day' and current_date  - interval '1 day')promedio  " +
                "from   " +
                "" + region + "." + sensor + " s, " + region + ".estacion e   " +
                "where   e.municipio in ('" + municipio + "')  " +
                "and  e.vereda in ('" + vereda + "')", new { });
            return longitudondainfra;

        }
        //Precipitacion
        public async Task<List<Precipitacion>> Precipitacion(string region, string municipio, string vereda, string sensor)
        {
            var precipitacion = await _dbService.TraerDatosDB<Precipitacion>("select distinct   " +
                "(select   cast(sum(a.precipitacion_lluvia)/count(a.precipitacion_lluvia)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day')siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'7 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.precipitacion_lluvia)/count(a.precipitacion_lluvia)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day')seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'6 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.precipitacion_lluvia)/count(a.precipitacion_lluvia)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day')cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'5 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.precipitacion_lluvia)/count(a.precipitacion_lluvia)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day')cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'4 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.precipitacion_lluvia)/count(a.precipitacion_lluvia)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day')tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'3 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.precipitacion_lluvia)/count(a.precipitacion_lluvia)as int)  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day')dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'2 day'::interval)  limit 1),  " +
                "(select   cast(sum(a.precipitacion_lluvia)/count(a.longitud_onda_infrarrojo)as int) " +
                "from   " +
                "" + region + "." + sensor + " a   where   a.fecha_registro  between current_date - interval '7 day' and current_date  - interval '1 day')promedio  " +
                "from   " +
                "" + region + "." + sensor + " s, " + region + ".estacion e   " +
                "where   e.municipio in ('" + municipio + "')  " +
                "and  e.vereda in ('" + vereda + "')", new { });
            return precipitacion;

        }
        //Velocidad Viento
        public async Task<List<VelocidadViento>> VelocidadViento(string region, string municipio, string vereda, string sensor)
        {
            var velocidadviento = await _dbService.TraerDatosDB<VelocidadViento>("select distinct   " +
               "(select   cast(sum(a.velocidad_viento)/count(a.velocidad_viento)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day')siete,  " +
               "(select   cast(a.fecha_registro as date) as fdsiete  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'7 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.velocidad_viento)/count(a.velocidad_viento)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day')seis,  " +
               "(select   cast(a.fecha_registro as date) as fseis  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'6 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.velocidad_viento)/count(a.velocidad_viento)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day')cinco,  " +
               "(select   cast(a.fecha_registro as date) as fcinco  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'5 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.velocidad_viento)/count(a.velocidad_viento)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day')cuatro,  " +
               "(select   cast(a.fecha_registro as date) as fcuatro  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'4 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.velocidad_viento)/count(a.velocidad_viento)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day')tres,  " +
               "(select   cast(a.fecha_registro as date) as ftres  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'3 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.velocidad_viento)/count(a.velocidad_viento)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day')dos,  " +
               "(select   cast(a.fecha_registro as date) as fdos  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'2 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.velocidad_viento)/count(a.velocidad_viento)as int) " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro  between current_date - interval '7 day' and current_date  - interval '1 day')promedio  " +
               "from   " +
               "" + region + "." + sensor + " s, " + region + ".estacion e   " +
               "where   e.municipio in ('" + municipio + "')  " +
               "and  e.vereda in ('" + vereda + "')", new { });
            return velocidadviento;

        }
        //Direccion Viento
        public async Task<List<DireccionViento>> DireccionViento(string region, string municipio, string vereda, string sensor)
        {
            var direccionviento = await _dbService.TraerDatosDB<DireccionViento>("select distinct   " +
               "(select   cast(sum(a.direccion_viento)/count(a.direccion_viento)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day')siete,  " +
               "(select   cast(a.fecha_registro as date) as fsiete  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'7 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.direccion_viento)/count(a.direccion_viento)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day')seis,  " +
               "(select   cast(a.fecha_registro as date) as fseis  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'6 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.direccion_viento)/count(a.direccion_viento)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day')cinco,  " +
               "(select   cast(a.fecha_registro as date) as fcinco  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'5 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.direccion_viento)/count(a.direccion_viento)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day')cuatro,  " +
               "(select   cast(a.fecha_registro as date) as fcuatro  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'4 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.direccion_viento)/count(a.direccion_viento)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day')tres,  " +
               "(select   cast(a.fecha_registro as date) as ftres  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'3 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.direccion_viento)/count(a.direccion_viento)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day')dos,  " +
               "(select   cast(a.fecha_registro as date) as fdos  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'2 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.direccion_viento)/count(a.direccion_viento)as int) " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro  between current_date - interval '7 day' and current_date  - interval '1 day')promedio  " +
               "from   " +
               "" + region + "." + sensor + " s, " + region + ".estacion e   " +
               "where   e.municipio in ('" + municipio + "')  " +
               "and  e.vereda in ('" + vereda + "')", new { });
            return direccionviento;

        }
        //Nivel Carga
        public async Task<List<NivelCarga>> NivelCarga(string region, string municipio, string vereda, string sensor)
        {
            var nivelcarga = await _dbService.TraerDatosDB<NivelCarga>("select distinct   " +
               "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day')siete,  " +
               "(select   cast(a.fecha_registro as date) as fsiete  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'7 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day')seis,  " +
               "(select   cast(a.fecha_registro as date) as fseis  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'6 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day')cinco,  " +
               "(select   cast(a.fecha_registro as date) as fcinco  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'5 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day')cuatro,  " +
               "(select   cast(a.fecha_registro as date) as fcuatro  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'4 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day')tres,  " +
               "(select   cast(a.fecha_registro as date) as ftres  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'3 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day')dos,  " +
               "(select   cast(a.fecha_registro as date) as fdos  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'2 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int) " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro  between current_date - interval '7 day' and current_date  - interval '1 day')promedio  " +
               "from   " +
               "" + region + "." + sensor + " s, " + region + ".estacion e   " +
               "where   e.municipio in ('" + municipio + "')  " +
               "and  e.vereda in ('" + vereda + "')", new { });
            return nivelcarga;

        }
        //Intensidad Luz
        public async Task<List<IntensidadLuz>> IntensidadLuz(string region, string municipio, string vereda, string sensor)
        {
            var intensidadluz = await _dbService.TraerDatosDB<IntensidadLuz>("select distinct   " +
               "(select   cast(sum(a.intensidad_luz)/count(a.intensidad_luz)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day')siete,  " +
               "(select   cast(a.fecha_registro as date) as fsiete  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'7 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.intensidad_luz)/count(a.intensidad_luz)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day')seis,  " +
               "(select   cast(a.fecha_registro as date) as fseis  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'6 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.intensidad_luz)/count(a.intensidad_luz)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day')cinco,  " +
               "(select   cast(a.fecha_registro as date) as fcinco  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'5 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.intensidad_luz)/count(a.intensidad_luz)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day')cuatro,  " +
               "(select   cast(a.fecha_registro as date) as fcuatro  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'4 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.intensidad_luz)/count(a.intensidad_luz)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day')tres,  " +
               "(select   cast(a.fecha_registro as date) as ftres  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'3 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.intensidad_luz)/count(a.intensidad_luz)as int)  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day')dos,  " +
               "(select   cast(a.fecha_registro as date) as fdos  " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro>=(now()-'2 day'::interval)  limit 1),  " +
               "(select   cast(sum(a.intensidad_luz)/count(a.intensidad_luz)as int) " +
               "from   " +
               "" + region + "." + sensor + " a   where   a.fecha_registro  between current_date - interval '7 day' and current_date  - interval '1 day')promedio  " +
               "from   " +
               "" + region + "." + sensor + " s, " + region + ".estacion e   " +
               "where   e.municipio in ('" + municipio + "')  " +
               "and  e.vereda in ('" + vereda + "')", new { });
            return intensidadluz;

        }

        /*----------------------------------------------------------------------------------------
         * ------------------------ SENSOR FERMENTACION ------------------------------------------
         */
        //Variables Sensor Fermentacion
        //Variables
        public async Task<List<Variables>> VariablesFermentacion()
        {
            var variables = await _dbService.TraerDatosDB<Variables>("select distinct   " +
                "column_name variable  " +
                "from     " +
                "information_schema.columns  " +
                "where   " +
                "table_name = 'sensor_fermentacion'  " +
                "and   ordinal_position between 3 and 8", new { });
            return variables;
        }
        //Promedios Variables
        public async Task<List<PromedioVariablesFermentacion>> PromedioVariablesFermentacion(string region, string municipio, string vereda, string sensor)
        {
            var promvariables = await _dbService.TraerDatosDB<PromedioVariablesFermentacion>("select   " +
                "cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int) temperatura_ambiente  ,  " +
                "cast(sum(a.temperatura_masa)/count(a.humedad_masa)as int) temperatura_masa ,  " +
                "cast(sum(a.humedad_ambiente)/count(a.humedad_ambiente)as int) humedad_ambiente  ,  " +
                "cast(sum(a.humedad_masa)/count(a.humedad_masa)as int) humedad_masa,  " +
                "cast(sum(a.ph)/count(a.ph)as int) ph,  " +
                "cast(sum(a.nivel_carga)/count(a.nivel_carga)as int) nivel_carga   " +
                "from    " +
                "" + region + "." + sensor + " a," + region + ".estacion e   " +
                "where    a.fecha_registro   between    (current_date - interval '7 day') and now()  " +
                "and   e.municipio = '" + municipio + "'  " +
                "and   e.vereda = '" + vereda + "'", new { });
            return promvariables;
        }
        //Temperatura Ambiente
        public async Task<List<TemperaturaAmbiente>> TemperaturaAmbiente(string region, string municipio, string vereda, string sensor)
        {
            var temperaturaAmbiente = await _dbService.TraerDatosDB<TemperaturaAmbiente>("select distinct   " +
                "(select   cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return temperaturaAmbiente;
        }
        //Temperatura Masa
        public async Task<List<TemperaturaMasa>> TemperaturaMasa(string region, string municipio, string vereda, string sensor)
        {
            var temperaturamasa = await _dbService.TraerDatosDB<TemperaturaMasa>("select distinct   " +
                "(select   cast(sum(a.temperatura_masa)/count(a.temperatura_masa)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "')  " +
                "and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_masa)/count(a.temperatura_masa)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_masa)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_masa)/count(a.temperatura_masa)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_masa)/count(a.temperatura_masa)as int)  " +
                "from   " + region + "." + sensor + " a    inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_masa)/count(a.temperatura_masa)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_masa)/count(a.temperatura_masa)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return temperaturamasa;
        }
        //Temperatura Ambiente
        public async Task<List<HumedadAmbiente>> HumedadAmbiente(string region, string municipio, string vereda, string sensor)
        {
            var humedadambiente = await _dbService.TraerDatosDB<HumedadAmbiente>("select distinct   " +
                "(select   cast(sum(a.humedad_ambiente)/count(a.humedad_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "')  " +
                "and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_ambiente)/count(a.humedad_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_ambiente)/count(a.humedad_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_ambiente)/count(a.humedad_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_ambiente)/count(a.humedad_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_ambiente)/count(a.humedad_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return humedadambiente;
        }
        //Temperatura Ambiente
        public async Task<List<HumedadMasa>> HumedadMasa(string region, string municipio, string vereda, string sensor)
        {
            var humedadmasa = await _dbService.TraerDatosDB<HumedadMasa>("select distinct   " +
                "(select   cast(sum(a.humedad_masa)/count(a.humedad_masa)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "')  " +
                "and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_masa)/count(a.humedad_masa)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_masa)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_masa)/count(a.humedad_masa)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_masa)/count(a.humedad_masa)as int)  " +
                "from   " + region + "." + sensor + " a    inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_masa)/count(a.humedad_masa)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_masa)/count(a.humedad_masa)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return humedadmasa;
        }
        //Ph
        public async Task<List<Ph>> Ph(string region, string municipio, string vereda, string sensor)
        {
            var ph = await _dbService.TraerDatosDB<Ph>("select distinct   " +
                "(select   cast(sum(a.ph)/count(a.ph)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "')  " +
                "and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.ph)/count(a.ph)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.ph)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.ph)/count(a.ph)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.ph)/count(a.ph)as int)  " +
                "from   " + region + "." + sensor + " a    inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.ph)/count(a.ph)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.ph)/count(a.ph)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return ph;
        }
        //Temperatura Ambiente
        public async Task<List<NivelCargaFermentacion>> NivelCargaFermentacion(string region, string municipio, string vereda, string sensor)
        {
            var nivelcarga = await _dbService.TraerDatosDB<NivelCargaFermentacion>("select distinct   " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "')  " +
                "and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return nivelcarga;
        }
        /*----------------------------------------------------------------------------------------
         * ------------------------ SENSOR HORNO -------------------------------------------------
         */
        //Variables Sensor Horno
        //Variables
        public async Task<List<Models.Nombre_Variables.Variables>> VariablesHorno()
        {
            var variables = await _dbService.TraerDatosDB<Models.Nombre_Variables.Variables>("select distinct " +
                "column_name variable " +
                "from " +
                "information_schema.columns " +
                "where table_name = 'sensor_horno' " +
                "and ordinal_position between 3 and 5", new { });
            return variables;
        }
        //Promedio Variables
        public async Task<List<PromedioVariablesHorno>> PromedioVariablesHorno(string region, string municipio, string vereda, string sensor)
        {
            var promvariables = await _dbService.TraerDatosDB<PromedioVariablesHorno>("select " +
                "cast(sum(a.temperatura)/count(a.temperatura)as int) temperatura," +
                "cast(sum(a.humedad)/count(a.humedad)as int) humedad ," +
                "cast(sum(a.nivel_carga)/count(a.nivel_carga)as int) nivel_carga " +
                "from  " +
                "" + region + ".sensor_horno a," + region + ".estacion e " +
                "where    a.fecha_registro   between    (current_date - interval '7 day') and now() " +
                "and   e.municipio = '" + municipio + "' and   e.vereda = '" + vereda + "'", new { });
            return promvariables;
        }
        //Temperatura
        public async Task<List<TemperaturaHorno>> TemperaturaHorno(string region, string municipio, string vereda, string sensor)
        {
            var temperatura = await _dbService.TraerDatosDB<TemperaturaHorno>("select distinct   " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return temperatura;
        }
        //Humedad
        public async Task<List<HumedadHorno>> HumedadHorno(string region, string municipio, string vereda, string sensor)
        {
            var humedad = await _dbService.TraerDatosDB<HumedadHorno>("select distinct   " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return humedad;
        }
        //Nivel Carga
        public async Task<List<NivelCargaHorno>> NivelCargaHorno(string region, string municipio, string vereda, string sensor)
        {
            var nivel_carga = await _dbService.TraerDatosDB<NivelCargaHorno>("select distinct   " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return nivel_carga;
        }
        /*----------------------------------------------------------------------------------------------------
         * ------------------------ SENSOR SUELO SUPERFICIAL -------------------------------------------------
         */
        //Variables Sensor Suelo Superficial
        //Variables
        public async Task<List<Variables>> VariablesSueloSuperficial()
        {
            var variables = await _dbService.TraerDatosDB<Variables>("select distinct " +
                "column_name variable " +
                "from " +
                "information_schema.columns " +
                "where table_name = 'sensor_suelo_superficial' " +
                "and ordinal_position between 3 and 9", new { });
            return variables;
        }
        //Promedio Variables
        public async Task<List<PromedioVariablesSuelo>> PromedioVariablesSuelo(string region, string municipio, string vereda, string sensor)
        {
            var promvariables = await _dbService.TraerDatosDB<PromedioVariablesSuelo>("select " +
                "cast(sum(s.temperatura_suelo)/count(s.temperatura_suelo)as int)temperatura_suelo," +
                "cast(sum(s.humedad_suelo)/count(s.humedad_suelo)as int)humedad_suelo," +
                "cast(sum(s.temperatura_ambiente)/count(s.temperatura_ambiente)as int)temperatura_ambiente," +
                "cast(sum(s.humedad_relativa_ambiente)/count(s.humedad_relativa_ambiente)as int)humedad_relativa_ambiente," +
                "cast(sum(s.luz_ambiente )/count(s.luz_ambiente)as int) luz_ambiente," +
                "cast(sum(s.conductividad_electrica)/count(s.conductividad_electrica)as int)conductividad_electrica," +
                "cast(sum(s.nivel_carga)/count(s.nivel_carga)as int) nivel_carga " +
                "from "+region+"."+sensor+" s " +
                "inner join "+region+".estacion e on e.id = s.id_estacion " +
                "where s.fecha_registro between    (current_date - interval '7 day') and now() " +
                "and e.municipio in ('"+municipio+"') and e.vereda in ('"+vereda+"')", new { });
            return promvariables;
        }
        //Temperatura Suelo
        public async Task<List<TemperaturaSuelo>> TemperaturaSuelo(string region, string municipio, string vereda, string sensor)
        {
            var TemperaturaSuelo = await _dbService.TraerDatosDB<TemperaturaSuelo>("select distinct   " +
                "(select   cast(sum(a.temperatura_suelo)/count(a.temperatura_suelo)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_suelo)/count(a.temperatura_suelo)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_suelo)/count(a.temperatura_suelo)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_suelo)/count(a.temperatura_suelo)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_suelo)/count(a.temperatura_suelo)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_suelo)/count(a.temperatura_suelo)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_suelo)/count(a.temperatura_suelo)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return TemperaturaSuelo;
        }
        //Humedad Suelo
        public async Task<List<HumedadSuelo>> HumedadSuelo(string region, string municipio, string vereda, string sensor)
        {
            var HumedadSuelo = await _dbService.TraerDatosDB<HumedadSuelo>("select distinct   " +
                "(select   cast(sum(a.humedad_suelo)/count(a.humedad_suelo)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_suelo)/count(a.humedad_suelo)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_suelo)/count(a.humedad_suelo)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_suelo)/count(a.humedad_suelo)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_suelo)/count(a.humedad_suelo)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_suelo)/count(a.humedad_suelo)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_suelo)/count(a.humedad_suelo)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return HumedadSuelo;
        }
        //Temperatura Ambiente Suelo
        public async Task<List<TemperaturaAmbienteSuelo>> TemperaturaAmbienteSuelo(string region, string municipio, string vereda, string sensor)
        {
            var TemperaturaAmbienteSuelo = await _dbService.TraerDatosDB<TemperaturaAmbienteSuelo>("select distinct   " +
                "(select   cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura_ambiente)/count(a.temperatura_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return TemperaturaAmbienteSuelo;
        }
        //Humedad Relativa Ambiente
        public async Task<List<HumedadRelativaAmbiente>> HumedadRelativaAmbiente(string region, string municipio, string vereda, string sensor)
        {
            var HumedadRelativaAmbiente = await _dbService.TraerDatosDB<HumedadRelativaAmbiente>("select distinct   " +
                "(select   cast(sum(a.humedad_relativa_ambiente)/count(a.humedad_relativa_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_relativa_ambiente)/count(a.humedad_relativa_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_relativa_ambiente)/count(a.humedad_relativa_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_relativa_ambiente)/count(a.humedad_relativa_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_relativa_ambiente)/count(a.humedad_relativa_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_relativa_ambiente)/count(a.humedad_relativa_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.humedad_relativa_ambiente)/count(a.humedad_relativa_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return HumedadRelativaAmbiente;
        }
        //Luz Ambiente
        public async Task<List<LuzAmbiente>> LuzAmbiente(string region, string municipio, string vereda, string sensor)
        {
            var LuzAmbiente = await _dbService.TraerDatosDB<LuzAmbiente>("select distinct   " +
                "(select   cast(sum(a.luz_ambiente)/count(a.luz_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.luz_ambiente)/count(a.luz_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.luz_ambiente)/count(a.luz_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.luz_ambiente)/count(a.luz_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.luz_ambiente)/count(a.luz_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.luz_ambiente)/count(a.luz_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.luz_ambiente)/count(a.luz_ambiente)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return LuzAmbiente;
        }
        //Conductividad
        public async Task<List<ConductividadElectrica>> ConductividadElectrica(string region, string municipio, string vereda, string sensor)
        {
            var ConductividadElectrica = await _dbService.TraerDatosDB<ConductividadElectrica>("select distinct   " +
                "(select   cast(sum(a.conductividad_electrica)/count(a.conductividad_electrica)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.conductividad_electrica)/count(a.conductividad_electrica)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.conductividad_electrica)/count(a.conductividad_electrica)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.conductividad_electrica)/count(a.conductividad_electrica)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.conductividad_electrica)/count(a.conductividad_electrica)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.conductividad_electrica)/count(a.conductividad_electrica)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.conductividad_electrica)/count(a.conductividad_electrica)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return ConductividadElectrica;
        }
        //Nivel de Carga Suelo
        public async Task<List<NivelCargaSuelo>> NivelCargaSuelo(string region, string municipio, string vereda, string sensor)
        {
            var NivelCargaSuelo = await _dbService.TraerDatosDB<NivelCargaSuelo>("select distinct   " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return NivelCargaSuelo;
        }
        /*----------------------------------------------------------------------------------------------------
         * ------------------------ SENSOR SUELO SUPERFICIAL AVANZADO-------------------------------------------------
         */
        //Variables Sensor Suelo Superficial Avanzado
        //Variables
        public async Task<List<Variables>> VariablesSueloSuperficialAvanzado()
        {
            var variables = await _dbService.TraerDatosDB<Variables>("select distinct " +
                "column_name variable " +
                "from " +
                "information_schema.columns " +
                "where table_name = 'sensor_suelo_superficial_avanzado' " +
                "and ordinal_position between 3 and 8", new { });
            return variables;
        }
        //Promedio Variables
        public async Task<List<PromedioVariablesSueloAvanzado>> PromedioVariablesSueloAvanzado(string region, string municipio, string vereda, string sensor)
        {
            var PromedioVariablesSueloAvanzado = await _dbService.TraerDatosDB<PromedioVariablesSueloAvanzado>("select " +
                "cast(sum(s.temperatura)/count(s.temperatura)as int)temperatura," +
                "cast(sum(s.humedad)/count(s.humedad)as int)humedad," +
                "cast(sum(s.conductividad_electrica)/count(s.conductividad_electrica)as int)conductividad_electrica," +
                "cast(sum(s.ph)/count(s.ph)as int)ph," +
                "cast(sum(s.npk )/count(s.npk)as int) npk," +
                "cast(sum(s.nivel_carga)/count(s.nivel_carga)as int) nivel_carga " +
                "from " + region + "." + sensor + " s " +
                "inner join " + region + ".estacion e on e.id = s.id_estacion " +
                "where s.fecha_registro between    (current_date - interval '7 day') and now() " +
                "and e.municipio in ('" + municipio + "') and e.vereda in ('" + vereda + "')", new { });
            return PromedioVariablesSueloAvanzado;
        }
        //Temperatura Suelo Avanzado
        public async Task<List<TemperaturaSueloA>> TemperaturaSueloA(string region, string municipio, string vereda, string sensor)
        {
            var TemperaturaSueloA = await _dbService.TraerDatosDB<TemperaturaSueloA>("select distinct   " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.temperatura)/count(a.temperatura)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return TemperaturaSueloA;
        }
        //Humedad Suelo Avanzado
        public async Task<List<HumedadSueloA>> HumedadSueloA(string region, string municipio, string vereda, string sensor)
        {
            var HumedadSueloA = await _dbService.TraerDatosDB<HumedadSueloA>("select distinct   " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return HumedadSueloA;
        }
        //Conductividad Electirca Suelo Avanzado
        public async Task<List<ConductividadElectricaSueloA>> ConductividadElectricaSueloA(string region, string municipio, string vereda, string sensor)
        {
            var ConductividadElectricaSueloA = await _dbService.TraerDatosDB<ConductividadElectricaSueloA>("select distinct   " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.humedad)/count(a.humedad)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return ConductividadElectricaSueloA;
        }
        //Ph Suelo Avanzado
        public async Task<List<PhSueloA>> PhSueloA(string region, string municipio, string vereda, string sensor)
        {
            var PhSueloA = await _dbService.TraerDatosDB<PhSueloA>("select distinct   " +
                "(select   cast(sum(a.ph)/count(a.ph)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.ph)/count(a.ph)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.ph)/count(a.ph)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.ph)/count(a.ph)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.ph)/count(a.ph)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.ph)/count(a.ph)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.ph)/count(a.ph)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return PhSueloA;
        }
        //Npk Suelo Avanzado
        public async Task<List<NpkSueloA>> NpkSueloA(string region, string municipio, string vereda, string sensor)
        {
            var NpkSueloA = await _dbService.TraerDatosDB<NpkSueloA>("select distinct   " +
                "(select   cast(sum(a.npk)/count(a.npk)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.npk)/count(a.npk)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.npk)/count(a.npk)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.npk)/count(a.npk)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.npk)/count(a.npk)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.npk)/count(a.npk)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.npk)/count(a.npk)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return NpkSueloA;
        }
        //Nivel Carga Suelo Avanzado
        public async Task<List<NivelCargaSueloA>> NivelCargaSueloA(string region, string municipio, string vereda, string sensor)
        {
            var NivelCargaSueloA = await _dbService.TraerDatosDB<NivelCargaSueloA>("select distinct   " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  " +
                "and    b.municipio in ('" + municipio + "') and   b.vereda  in ('" + vereda + "')  )  siete,  " +
                "(select   cast(a.fecha_registro as date) as fsiete  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '7 day' and current_date  - interval '6 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  seis,  " +
                "(select   cast(a.fecha_registro as date) as fseis  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '6 day' and current_date  - interval '5 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cinco,  " +
                "(select   cast(a.fecha_registro as date) as fcinco  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '5 day' and current_date  - interval '4 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  cuatro,  " +
                "(select   cast(a.fecha_registro as date) as fcuatro  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '4 day' and current_date  - interval '3 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  tres,  " +
                "(select   cast(a.fecha_registro as date) as ftres  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '3 day' and current_date  - interval '2 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  dos,  " +
                "(select   cast(a.fecha_registro as date) as fdos  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '2 day' and current_date  - interval '1 day'  limit 1),  " +
                "(select   cast(sum(a.nivel_carga)/count(a.nivel_carga)as int)  " +
                "from   " + region + "." + sensor + " a    " +
                "inner join   " + region + ".estacion b on b.id = a.id_estacion  " +
                "where  a.fecha_registro between current_date - interval '1 day' and current_date   " +
                "and    b.municipio in ('" + municipio + "')  and   b.vereda  in ('" + vereda + "')  )  uno,  " +
                "(select   cast(a.fecha_registro as date) as funo  " +
                "from   " + region + "." + sensor + " a   " +
                "where   a.fecha_registro between current_date - interval '1 day' and current_date  limit 1)  " +
                "from   " + region + "." + sensor + "   ;", new { });
            return NivelCargaSueloA;
        }

        //----------------------------------------> Login
        public async Task<List<Login>> Login()
        {
            var login = await _dbService.TraerDatosDB<Login>("select l.usuario usuario ,l.pass password from configuracion.login l ;", new { });
            return login;
        }
        //----------------------------------------> Parametrizacion
        //----------------------------------------> Sensores
        public async Task<List<SensoresParametrizacion>> SensoresParametrizacion()
        {
            var sensores = await _dbService.TraerDatosDB<SensoresParametrizacion>("select distinct a.sensor variable from configuracion.variables a", new { });
            return sensores;
        }
        //----------------------------------------> Sensores
        public async Task<List<VariablesBasico>> VariablesSensores(string sensor)
        {
            var variables = await _dbService.TraerDatosDB<VariablesBasico>("select  " +
                "a.variable " +
                "from " +
                "configuracion.variables a " +
                "where   a.sensor = '"+sensor+"'order by a.variable asc", new { });
            return variables;
        }
        //----------------------------------------> Sensores
        public async Task<variablesSensorBasico> ActualizarVarSensores(variablesSensorBasico variablebasico, string sensor, string variable)
        {
            var actualizar = await _dbService.EditData("update " +
                "configuracion.variables SET " +
                "co_value1=@co_value1," +
                "co_value2=@co_value2," +
                "co_mensaje=@co_mensaje," +
                "cc_value1=@cc_value1," +
                "cc_value2=@cc_value2 ," +
                "cc_mensaje=@cc_mensaje," +
                "cm_mensaje=@cm_mensaje ," +
                "rango=@rango "+
                "where variable='"+variable+"' and sensor = '"+sensor+"'"  , variablebasico);
            return variablebasico;
        }
        public async Task<List<variablesSensorBasico>> DatosBasico(string sensor,string variable)
        {
            var variables = await _dbService.TraerDatosDB<variablesSensorBasico>("select " +
                "s.co_value1 ," +
                "s.co_value2 ," +
                "s.co_mensaje ," +
                "s.cc_value1 ," +
                "s.cc_value2 ," +
                "s.cc_mensaje ," +
                "s.cm_mensaje ," +
                "s.rango " +
                "from " +
                "configuracion.variables s where variable = '"+variable+"' and sensor = '"+sensor+"';", new { });
            return variables;
        }
        public async Task<List<variablesSensorBasico>> DatosBasicoProm(string sensor, string variable)
        {
            var variables = await _dbService.TraerDatosDB<variablesSensorBasico>("select " +
                "s.co_value1 ," +
                "s.co_value2 ," +
                "s.co_mensaje ," +
                "s.cc_value1 ," +
                "s.cc_value2 ," +
                "s.cc_mensaje ," +
                "s.cm_mensaje ," +
                "s.rango " +
                "from " +
                "configuracion.variables s where variable = '"+variable+"' and sensor = '"+sensor+"';", new { });
            return variables;
        }
        //-------------------------------------------> Fin Sensores
    }
}
